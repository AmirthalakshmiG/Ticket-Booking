<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Flasher\Prime\FlasherInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class Index extends Controller
{
    function __construct() {
        $this->middleware('auth');
        $this->middleware('role_or_permission:SuperAdmin|AdminPanel access', ['only' => 'index']);
    }

    public function index(FlasherInterface $flasher) {
        $flasher->addSuccess('Welcome '. auth()->user()->name . '!', 'Dash UI' );
        // Total users count
        $totalUsers = User::count(); 
        // Active users count
        $activeUsers = User::where('is_active', 1)->count(); 
        // Inactive users count
        $inactiveUsers = User::where('is_active', 0)->count(); 
        return view('admin.index', compact('totalUsers', 'activeUsers', 'inactiveUsers'));
    }
}
