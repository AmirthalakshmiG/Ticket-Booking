<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateUser;
use App\Models\User;
use App\Models\TicketPrice;
use App\Models\Ticket;
use Flasher\Prime\FlasherInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Traits\HasRoles;
use Carbon\Carbon;

class TicketController extends Controller
{
    use HasRoles;
 

    public function dashboard(FlasherInterface $flasher) {
        $flasher->addSuccess('Welcome '. auth()->user()->name . '!', 'Dash UI' );
       // Total count
        $totalCount = Ticket::where('user_id', auth()->user()->id)->count();

        // Today's count
        $todayCount = Ticket::where('user_id', auth()->user()->id)
                        ->whereDate('created_at', Carbon::today())
                        ->count();
        return view('user.index',compact('totalCount','todayCount'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tickets = Ticket::where(['user_id'=>auth()->user()->id])->get();  
        return view('user.ticket.index', compact('tickets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tickets = [];
        return view('user.ticket.create', compact('tickets'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:150',
            'age' => 'required|integer|min:0',
            'price' => 'required|numeric|min:0|max:999999.99', 
            'quantity' => 'required|integer|min:1|max:100',  
            'booking_date' => 'required|date|after_or_equal:today', 
        ]);

         // Check if the user has already booked for this date
        $existingBooking = Ticket::where('email', $request->email)
                                    ->where('booking_date', $request->booking_date)
                                    ->first();

        if($existingBooking){
            return back()->with('error', 'You have already booked a ticket for this date.');
        }

        // Fetch price based on age
        $price = TicketPrice::where('min_age', '<=', $request->age)
                    ->where('max_age', '>=', $request->age)
                    ->first();

        if(!$price){
            return back()->with('error', 'No price found for this age.');
        }

        // Store ticket booking
        $totalPrice = $price->price * $request->quantity; 
        Ticket::create([
            'user_id' => auth()->id(),
            'name' => $request->name,
            'email' => $request->email,
            'age' => $request->age,
            'price' => $price->price,
            'user_type' => $price->category,
            'quantity' => $request->quantity,
            'total_price' => $totalPrice,
            'booking_date' => date('Y-m-d', strtotime($request->booking_date))
        ]); 
        return redirect()->route('user.ticket.index')->with('success', 'Ticket booked successfully.');
    }

    public function getPrice(Request $request)
    {
        $request->validate([
            'age' => 'required|integer|min:0',
        ]);

        $price = TicketPrice::where('min_age', '<=', $request->age)
                    ->where('max_age', '>=', $request->age)
                    ->first();

        if($price){
            return response()->json(['price' => $price->price]);
        } else {
            return response()->json(['price' => 'No price found']);
        }
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return redirect(route('admin.users.index'));
    }
 

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy(FlasherInterface $flasher,$id)
    {
        $ticket = Ticket::where('id', $id)->where('user_id', auth()->id())->firstOrFail();
        $ticket->delete();
        $flasher->addInfo('Ticket Deleted Successfully', 'Dash UI');
        return redirect()->back();
    }
 
}
