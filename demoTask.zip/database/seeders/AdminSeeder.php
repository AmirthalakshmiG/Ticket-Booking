<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $superAdmin = User::create([
            'name' => 'SuperAdmin',
            'email' => 'superadmin@yopmail.com',
            'password'  => Hash::make('123456'),
            'is_active' => '1',
            'created_at' => now(),
            'updated_at' => now()
        ]);

        

        $user = User::create([
            'name' => 'Amirtha',
            'email' => 'amirtha@yopmail.com',
            'password'  => Hash::make('123456'),
            'is_active' => '1',
            'created_at' => now(),
            'updated_at' => now()
        ]);

        $superAdmin->assignRole('SuperAdmin'); 
        $user->assignRole('User');
    }
}
