<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\TicketPrice;

class TicketPriceSeeder extends Seeder
{
    public function run()
    {
        // Delete existing records (optional)
        TicketPrice::truncate();

        // Insert ticket prices
        TicketPrice::create([
            'category' => 'Kids',
            'min_age' => 0,
            'max_age' => 12,
            'price' => 100.00,
        ]);

        TicketPrice::create([
            'category' => 'Teen',
            'min_age' => 13,
            'max_age' => 17,
            'price' => 150.00,
        ]);

        TicketPrice::create([
            'category' => 'Adult',
            'min_age' => 18,
            'max_age' => 59,
            'price' => 250.00,
        ]);

        TicketPrice::create([
            'category' => 'Senior',
            'min_age' => 60,
            'max_age' => 120,
            'price' => 200.00,
        ]);
    }
}
