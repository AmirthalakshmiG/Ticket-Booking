@extends('layouts.admin')

@section('breadcrumb')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="{{ route('admin.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="{{ route('admin.users.index') }}">Users</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Create User</li>
        </ol>
        <h5 class="font-weight-bolder mb-0">User Management</h5>
    </nav>
@stop

@section('content')

    <div class="container-fluid py-4">
        <div class="card">
            <div class="card-header pb-0 px-3">
                <h5 class="mb-0">Add Ticket</h5>
            </div>
            <div class="card-body pt-4 p-3">
            <form action="{{ route('user.ticket.store') }}" method="POST" class="space-y-4">

                     @csrf
                    @if($errors->any())
                        <div class="alert alert-primary alert-dismissible fade show" role="alert">
                            @foreach ($errors->all() as $message)
                            <ul style="list-style-type: none;">
                                <li>
                                     <span class="alert-text text-white">{{$message}}</span>
                                </li>
                            </ul>
                            @endforeach
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                <i class="fa fa-close" aria-hidden="true"></i>
                            </button>
                        </div>
                    @endif
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group has-validation">
                                <label for="user-name" class="form-control-label">{{ __('Full Name') }}</label>
                                <div class="@error('user.name')border border-danger rounded-3 @enderror">
                                    <input class="form-control" type="text" placeholder="Name" id="user-name" name="name" value="{{ old('name') }}">
                                    @error('name')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email" class="form-control-label">{{ __('Email') }}</label>
                                <div class="@error('email')border border-danger rounded-3 @enderror">
                                    <input class="form-control" type="email" placeholder="@example.com" id="email" name="email" value="{{ old('email') }}">
                                    @error('email')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </div>
                      
                    </div>

                 <div class="row">
                  
                     <div class="col-md-6">
                            <div class="form-group">
                                <label for="age" class="form-control-label">{{ __('Booking Date') }}</label>
                                <div class="@error('user.booking_date')border border-danger rounded-3 @enderror">
                                <input class="form-control" type="date" placeholder="dd/mm/yyyy" id="booking_date" name="booking_date" value="{{ old('booking_date') }}">

                                    @error('booking_date')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                     </div>

                     <div class="col-md-6">
                            <div class="form-group">
                                <label for="age" class="form-control-label">{{ __('Age') }}</label>
                                <div class="@error('user.age')border border-danger rounded-3 @enderror">
                                <input class="form-control" type="number" placeholder="age" id="age" name="age" value="{{ old('age') }}">

                                    @error('age')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                     </div>

                    </div>
                    <div class="row">
                      
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="username" class="form-control-label">{{ __('Price Per Ticket') }}</label>
                                <div class="@error('user.username')border border-danger rounded-3 @enderror">
                                    <div class="input-group flex-nowrap">
                                  
                                    <input class="form-control" type="text" placeholder="Price" id="price" aria-describedby="addon-wrapping" name="price" value="{{ old('price') }}">
                                    </div>
                                    @error('price')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="age" class="form-control-label">{{ __('No of Tickets') }}</label>
                                <div class="@error('user.quantity')border border-danger rounded-3 @enderror">
                                <input class="form-control" type="number" placeholder="quantity" id="quantity" name="quantity">

                                    @error('quantity')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="age" class="form-control-label">{{ __('Total Price') }}</label>
                                <div class="@error('user.age')border border-danger rounded-3 @enderror">
                                <input class="form-control" type="number" placeholder="0" id="total_price" name="total_price" value="{{ old('total_price') }}">

                                    @error('total_price')
                                    <p class="text-danger text-xs mt-2">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </div>

                    </div>
                  
                   
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn bg-gradient-dark btn-md mt-4 mb-4">{{ 'Create Ticket' }}</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <script src="{{ asset('js/jquery.js') }}"></script>
<script>
$(document).ready(function() {

    function calculateTotal(){
        var price = parseFloat($('#price').val());
        var qty = parseInt($('#quantity').val());
        if(!isNaN(price) && !isNaN(qty)){
            $('#total_price').val((price * qty).toFixed(2));
        } else {
            $('#total_price').val('');
            $('#quantity').val('');
        }
    }

    $('#age').on('change', function(){
        var age = $(this).val();
      
        if(age!=''){
            $.ajax({
                url: "{{ route('user.ticket.getPrice') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    age: age
                },
                success: function(response){
                    if(response.price){
                        $('#price').val(response.price);
                        calculateTotal();
                    } else {
                        $('#price').val(''); 
                        $('#total_price').val('0');
                        $('#quantity').val('0'); 
                    }
                }
            });
        } else {
            $('#price').val('');
            $('#total_price').val('');
        }
    });

    $('#quantity').on('input', function(){
        calculateTotal();
    });
});
</script>
@stop
