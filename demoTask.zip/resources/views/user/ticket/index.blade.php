@extends('layouts.admin')

@section('breadcrumb')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="{{ route('admin.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Users</li>
        </ol>
        <h5 class="font-weight-bolder mb-0">Ticket Management</h5>
    </nav>
@stop

@section('content')

    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-6 d-flex align-items-center">
                            <h6>All Tickets</h6>
                        </div>
                        <div class="col-6 text-end">
                            <a class="btn bg-gradient-dark mb-0" href="{{ route('user.ticket.create') }}"><i class="fas fa-plus"></i>&nbsp;&nbsp;Add Ticket</a>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">User</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Email</th> 
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Category</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Age</th> 
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Booking Date</th>
                                 <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Price</th>
                                 <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No's of Ticket</th> 
                                 <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Total Price</th>

                                <th class="text-secondary opacity-7"></th>
                            </tr>
                            </thead>
                            <tbody> 
                            @forelse($tickets as $user)
                            <tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
  
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-0 text-sm">{{ $user->name }}</h6>
                                         </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ $user->email }}</span>
                                </td>
                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ $user->user_type }}</span>
                                </td>
                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ $user->age }}</span> 
                                </td>
                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ date('d-m-Y', strtotime($user->booking_date)) }}</span> 

                                </td>
                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ $user->price }}</span> 
                                </td>

                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ $user->quantity }}</span> 
                                </td>

                                <td>
                                    <span class="text-secondary text-xs font-weight-bold">{{ $user->total_price }}</span> 
                                </td>
                                 
                                <td class="align-middle">
                                <form action="{{ route('user.ticket.destroy', $user->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this ticket?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"  class="cursor-pointer fas fa-trash text-secondary" style="border: none; background: no-repeat;" data-bs-toggle="tooltip" data-bs-original-title="Delete Ticket"></button>

                                 </form>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="7" class="px-4 py-2 border text-center">No tickets booked yet.</td>
                            </tr>
                            @endforelse 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
